
$(function(){
    
   // $("#tablen,#tablew,#tablee,#tables").css("display","none");
    $("#north").click(function(){
        event.preventDefault()
        $("#tablen,#tablew,#tablee,#tables").fadeOut(function(){
            $("#tablen").fadeIn();
        });
       
    });
    $("#west").click(function(){
        event.preventDefault()
        $("#tablen,#tablew,#tablee,#tables").fadeOut(function(){
            $("#tablew").fadeIn();
        });
   
    });
    $("#east").click(function(){
        event.preventDefault()
        $("#tablen,#tablew,#tablee,#tables").fadeOut(function(){
            $("#tablee").fadeIn();
        });
   
    });
    $("#south").click(function(){
        event.preventDefault()
        $("#tablen,#tablew,#tablee,#tables").fadeOut(function(){
            $("#tables").fadeIn();
        });

    });
})
    

$(function(){
    var $window = $(window);
var $elem = $("#con")

    function isScrolledIntoView($elem, $window) {
        var docViewTop = $window.scrollTop();
        var docViewBottom = docViewTop + $window.height();

        var elemTop = $elem.offset().top;
        var elemBottom = elemTop + $elem.height();

        return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
    }


$(document).on("scroll", function () {
    if (isScrolledIntoView($elem, $window)) {
        $elem.addClass("animate")
        
    }
});
})
$(function(){
    var $window = $(window);
var $elem = $("#pills")

    function isScrolledIntoView($elem, $window) {
        var docViewTop = $window.scrollTop();
        var docViewBottom = docViewTop + $window.height();

        var elemTop = $elem.offset().top;
        var elemBottom = elemTop + $elem.height();

        return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
    }


$(document).on("scroll", function () {
    if (isScrolledIntoView($elem, $window)) {
        $elem.addClass("animate")
        
    }
});
})
